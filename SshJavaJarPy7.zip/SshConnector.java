/*
https://gist.github.com/kdelfour/5f1fde64c3d23daea704
rev.10.26.21
rev6 11.22.2021
based on SshJava6
 */
//package sshconnector;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;


import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;


public class SshConnector implements AutoCloseable{

    boolean connected;
    // Constants
    private static final String STRICT_HOSTKEY_CHECKIN_KEY = "StrictHostKeyChecking";
    private static final String STRICT_HOSTKEY_CHECKIN_VALUE = "no";
    private static final String CHANNEL_TYPE = "shell";
    SshConnector sshConnector;
    // SSH server ip
    String ip;
    // SSH server port
    int port;
    // User
    String user;
    // User password
    String password;
    // Connection timeout
    private int timeout;
    private Session session;
    private PrintStream ps;
    private InputStream input;
    private OutputStream ops;
    private Channel channel;
/*
    String ip;
    int port;
    String user;
    String password;
    int timeout;
*/
    public SshConnector() {

        super();
		//ip="172.20.4.182";
		port=22;
		connected=false;
		//user="root";
       // password="iDirect";
        System.out.println("SshConnector.class Constructor ");

	}

    //connect and send message thru SSH
    public Integer sendMessage_SSH(){
		//ip="172.20.4.182";
		port=22;
		//connected=false;
		//user="root";
        password="abc";

		int ctl=4;
		System.out.println("sendMessage_SSH");
		//ctl=open();

		try{


			//open SSH connection
			//open();
/*
			sendCommand("ls");
			sendCommand("pwd");


			sendCommand("cd ..");
			sendCommand("pwd");
			sendCommand("cd /bin");
			sendCommand("ls");
			sendCommand("cd ~");
			sendCommand("ls");
*/
			sendCommand("me");


      }  catch(IOException e2){ctl=0;}

		return ctl;
	}
    public String sendCommandMessage(String cmd){

		   return cmd;
   }
   //set iq200 freq
   public Integer setFrequency(int f){

		int error=0;
		try{
		sendCommand("tx_cross_pol_test PN 950 -50 2000 8 0");
		error=1;
		}  catch(IOException e2){error=-1;}
		return error;
   }

   // make sure that there is corect ip, username, password received
	public Integer test(int s){
		s=2*s;
		System.out.println("SshConnector4.java="+s);

		return s;
	}
	public String setIP(String IP){
		ip=IP;
		return ip;
	}
	public String setUser(String usr){

		user=usr;
		return user;
	}
	public String setPassword(String pswd){
		password=pswd;
		return password;
	}
	public String getRev(){
		return "ShsConnector rev.8";
	}
	public String getIP(){

		return ip;
	}
	public String getUser(){

		return user;
	}
	public String getPassword(){

		return password;
	}
	public Integer test1(int s){
		System.out.println("SshConnector8.java="+s);
		s=3*s;
		return s;
	}
	public boolean open() {

		System.out.println("open() ssh");
		boolean connect=false;
		try{

		// Prepare session
		final JSch jsch = new JSch();
		System.out.println("opened new JSsh");
		session = jsch.getSession(user, ip, port);
		session.setPassword(password);
		session.setTimeout(timeout);
		session.setConfig(STRICT_HOSTKEY_CHECKIN_KEY,  STRICT_HOSTKEY_CHECKIN_VALUE);
		session.connect();
		System.out.println("connected");
		channel = session.openChannel(CHANNEL_TYPE);
		input = channel.getInputStream();
		ops = channel.getOutputStream();
		ps = new PrintStream(ops, true);
		channel.connect();
		connected=true;

		}  catch(JSchException e1){} catch(IOException e2){connected=false;}
		return connected;
	}
        //send telnet login thru ssh
    public String sendTelnetLoginSshCommand(String command) throws IOException {

		System.out.print("SshConnector.class try to sendCommand() cmd="+command);
		ps.print(command);
		int size = 1024;
		final byte[] tmp = new byte[size];
		final StringBuilder sb = new StringBuilder();

		while (input.available() > 0) {

			int i = input.read(tmp, 0, 1024);
			if (i < 0) { break; }
			sb.append(new String(tmp, 0, i));
		}

		final String output = sb.toString();
		if (channel.isClosed()) {
				System.out.println("channel is closed");
		}

		try { Thread.sleep(1000); } catch (Exception e) {    }

	    return sb.toString();
	}
                //send ssh character
	public String sendCharacter(char  command) throws IOException {

		//System.out.println("sendCommand() cmd="+command);
		//command=command+"\r";
		//  command=command+"\r\n";
		ps.print(command);
		ps.flush();
		wait(500);// added 04.04.2019 now sent command matches received data
		int size = 1024;
		final byte[] tmp = new byte[size];
		final StringBuilder sb = new StringBuilder();

		while (input.available() > 0) {

			// int i = input.read(tmp, 0, 1024);//out rev46
			int i = input.read(tmp);
			if (i < 0) { break; }

			sb.append(new String(tmp, 0, i));
		}
		final String output = sb.toString();
		System.out.println("ssh output="+output);

		if (channel.isClosed()) {
			System.out.println("channel is closed");
				if (input.available() > 0) {

					int i = input.read(tmp);
					sb.append(new String(tmp));
				}
		}

		try { Thread.sleep(1000); } catch (Exception e) {

			System.out.println("SSH connection problem");
		}

	    return sb.toString();
	}
        //send ssh command
    public String sendCommand(String command) throws IOException {

		//System.out.println("SSH sendCommand() cmd="+command);
		command=command+"\n";

		ps.println(command);
		ps.flush();
		wait(1000);// 10 secs needed 04.04.2019 now sent command matches received data
		int size = 1024;

		final byte[] tmp = new byte[size];
		final StringBuilder sb = new StringBuilder();

		while (input.available() > 0) {

			int i = input.read(tmp);

			if (i < 0) {  break; }

			sb.append(new String(tmp, 0, i));
		}

		final String output = sb.toString();
		//System.out.println("SIDU received string thru SSH output="+output);
		if (channel.isClosed()) {
			System.out.println("channel is closed");

		}

		try { Thread.sleep(500); } catch (Exception e) {

			System.out.println("SSH connection problem");
		}
		System.out.println("received string thru SSH done");
	    return sb.toString();
	}

        //another method to send cmd
	public String executeCommand(String command) throws IOException {

		System.out.println("SshConnector execute cmd="+command);
		ps.println(command);
		wait(1000);
		int size = 1024;
		final byte[] tmp = new byte[size];
		final StringBuilder sb = new StringBuilder();
		int count=0;
		while (true) {

			System.out.println("executeCommand() 1st while count="+count);
			count++; if (count>20)break;
			while (input.available() > 0) {

				//int i = input.read(tmp, 0, 1024); out rev 46
				int i = input.read(tmp);

				if (i < 0) {break;}

				//sb.append(new String(tmp, 0, i)); out rev46
				sb.append(new String(tmp)); //new rev46
				System.out.println("received string thru SSH sb="+sb+"EOsb");

			}

			final String output = sb.toString();


			if (channel.isClosed()) {
				System.out.println("channel is closed");
					if (input.available() > 0) {
							//int i = input.read(tmp, 0, 1024);
							int i = input.read(tmp);//new rev46
							//sb.append(new String(tmp, 0, i));
							sb.append(new String(tmp));
							System.out.println("channel.isClosed() sb="+sb+"EOsb");
					}
					break;
			}

			try {
					Thread.sleep(1000);
			} catch (Exception e) {	System.out.println("SSH connection problem");}
	}//end  while(true)
			System.out.println("done command has been sent read from ULCT sb="+sb);
		    return sb.toString();
	}
    public void close() {


		try{
			System.out.println("SSH channel close");
			// Close channel
			channel.disconnect();
			// Close session
			session.disconnect();

		 }   catch(Exception e2){}

    }
	public void wait(int ms){

		try {
			 //thread to sleep for the specified number of milliseconds
			  Thread.sleep(ms);
			} catch ( java.lang.InterruptedException ie) { System.out.println(ie);}

	}
        public static void main(String[] args) {

            // TODO code application logic here
            System.out.println("start SIDU SSH Connection()");

            String IP="172.20.4.182";
            int Port=22;
            boolean connected=false;
            String user="root";
            String password="iDirect";
            //password="P@55w0rd!";
            int timeout=5000;
            //new SshConnector(IP,Port,user,password,timeout);
            //to work with JPype
            new SshConnector();
        }

}

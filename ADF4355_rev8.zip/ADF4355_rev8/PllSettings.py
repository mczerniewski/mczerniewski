# -*- coding: utf-8 -*-
"""
Created on Fri Nov 26 20:26:26 2021

@author: house
"""
import fractions
import math
from decimal import Decimal

class PllSettings:
    
  print ('PllSettings class') 
  par1=1
  par2=2
  
  def __init__(self,Fout):

    self.Fout=float(Fout)    
    
    self.RefOscFreq_MHz=50 # REFIN is the reference input frequency.         
    self.FundamentalMode=False # VCO fedback to PFD directly
    self.DividedMode=True # VCO feedback to PFD thru Out Divider
    self.ManualMode=False
    self.AutomaticMode=True
    self.getOutputDivider()
    
    self.MOD1 = 16777216
    self.MOD2max = 16383
    # self.frac1   
    self.Pfd=99.9
    self.RefIn=50.0
    self.D=0 #D is the REFIN doubler bit.
    self.R=10 #R is the preset divide ratio of the binary 10-bit programmable reference counter (1 to 1023)
    self.T=0 # T is the REFIN divide by 2 bit (0 or 1).    
    self.getPhaseDetFrequency() 
    self.Fout=Fout #PLL output frequency in MHz
    print('OutDivider (2^x) x=',self.OutputDivider)
    self.getSynthSettings(self.Fout,self.OutputDivider)
    self.getPllParams()
 
  def getPllParams(self):    
      
    print ('self.FRAC1=',self.FRAC1)
    print ('self.FRAC2=',self.FRAC2)
    print ('self.MOD1=',self.MOD1)
    print ('self.MOD2=',self.MOD2)
    
    return self.MOD1,self.MOD2,self.FRAC1,self.FRAC2,self.OutputDivider,self.INT
    
  def getOutputDivider(self):
      
      # VCO range 3400 MHz to 6800
      print('fout type=',type(self.Fout))
      div=99
      if self.Fout*2<=6800 and self.Fout*2>=3400:
         div=1
      if self.Fout*4<=6800 and self.Fout*4>=3400:
         div=2
      if self.Fout*8<=6800 and self.Fout*8>=3400:
         div=3
      if self.Fout*16<=6800 and self.Fout*16>=3400:
         div=4
      if self.Fout*32<=6800 and self.Fout*32>=3400:
         div=5    
      if self.Fout*64<=6800 and self.Fout*64>=3400:
         div=6
      if div<99:
          self.OutputDivider=div
          print("OutputDivider 2^x x=",self.OutputDivider)
      else:
          print ('no solution for Output Divider and VCO')

         
  def getPhaseDetFrequency(self):
        self.Fpd = self.RefIn* ((1 + self.D)/(self.R *(1 + self.T)))
        print ("Fpd=",self.Fpd)
        
        
  def getSynthSettings(self,RFout,OutputDivider):
      #Fout=float(Fout)
      print('getSyntSettings RFout=',RFout, ' OutputDivider=',math.pow(2,OutputDivider))
      print('Fout type=',type(self.Fout))
      if self.DividedMode:
         
         if self.AutomaticMode:
                
            print('get PLL settings ', self.Fout,OutputDivider)
            PrescalerInputFrequency = float(self.Fout) *( math.pow(2, OutputDivider))
            print(' PrescalerInputFrequency=', PrescalerInputFrequency)
            N = PrescalerInputFrequency / self.Fpd
            print('N=',N)

            INT = int(N)
            self.INT=INT
            FRAC1 = int((N - INT) *self.MOD1)
            residue = self.MOD1 * (N - (INT + FRAC1 / self.MOD1));
            MOD2 = (self.Fpd * 1000000);     # gcd;
            if MOD2 > self.MOD2max:
                MOD2 = self.MOD2max
            FRAC2 = residue * MOD2;
            print('FRAC2=',FRAC2)
            
            #original from C
            #FRAC2 = math.round(FRAC2, 0, MidpointRounding.AwayFromZero);
            #in Py
            #FRAC2=Decimal.from_float(FRAC2).quantize(exponent, rounding=ROUND_HALF_EVEN)
            FRAC2=round(FRAC2)

            D = int(math.gcd(MOD2, FRAC2))
            MOD2 = MOD2 / D;
            FRAC2 = FRAC2 / D;

            if MOD2 > self.MOD2max:
            
                MOD2 = self.MOD2max;
                FRAC2 = residue * self.MOD2max;
                #FRAC2 = Math.Round(FRAC2, 0, MidpointRounding.AwayFromZero);
                FRAC2=int(FRAC2) # mc temp
            

            if FRAC2 == MOD2:
            
                print("Error. Ensure step size is small enough for desired output frequency.");
            

            N = INT + ((FRAC1 + (FRAC2 / MOD2)) / self.MOD1);
          
            
            # INTBox_ = INT;
            # MOD2Box_ = MOD2;
            # FRAC1Box_ = FRAC1;
            # FRAC2Box_ = FRAC2;
           
            actualVCOoutput = FRAC2 / MOD2;
            print('vco=',actualVCOoutput)
            actualVCOoutput = FRAC1 + actualVCOoutput;
            actualVCOoutput = actualVCOoutput / self.MOD1;
            actualVCOoutput = actualVCOoutput + INT;
            actualVCOoutput = actualVCOoutput * self.Fpd;
            print('vco=',actualVCOoutput)
            # For divided feedback, the actual VCO output error needs to be calculated taking the divideed feedback into consideration
            #actualVCOoutput = actualVCOoutput * math.pow(2, OutputDivider)

            #ActualVCOoutputBox.Text = actualVCOoutput.ToString("0.#######################");
            #VCOOutputFrequencyError = Math.Round(((actualVCOoutput - VCOFreqBox.Value) * 1000000), 12, MidpointRounding.AwayFromZero)
            VCOOutputFrequencyError =round( (actualVCOoutput - PrescalerInputFrequency) * 1000000,12)
            MOD2=int(MOD2)
            FRAC2=int(FRAC2)
            print('N=',N)
            print('FRAC1=',FRAC1)
            print('MOD2=',MOD2)
            print('FRAC1=',FRAC1)
            print('FRAC2=',FRAC2)
        
            RFout_= float(self.Fout)/ math.pow(2, OutputDivider);
            print ('freq err=',VCOOutputFrequencyError)            
            print ('VCOFreq=',actualVCOoutput)
            
            self.FRAC1=FRAC1
            self.FRAC2=FRAC2            
            self.MOD2=MOD2
        
 
#pllSettings=PllSettings(910.9)

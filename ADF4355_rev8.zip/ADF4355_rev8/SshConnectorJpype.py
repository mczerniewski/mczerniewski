# -*- coding: utf-8 -*-
"""
Created on Sun Oct 24 11:07:08 2021
https://stackoverflow.com/questions/55717482/jpype-simple-jar-import-and-run-main
rev3
@author: mczerniewski
"""

import os
import jpype
from jpype import startJVM, shutdownJVM, java, addClassPath, JClass, JInt

import jpype.imports

#jpype.startJVM()

#add classpathe when launching SshConnector from other than SshJavaPy6 folder
#classpath=["C:\\SshJavaPy6\\"]
#jpype.startJVM(jpype.getDefaultJVMPath(), "-ea",classpath=["C:/SshJavaJarPy7/"] )
	
#===========================================

# -*- coding: utf-8 -*-
"""
Created on Fri Oct  8 21:40:47 2021

_jpype _core.py modified x=0 and x=-1 added
if _jpype.isStarted():
        x=0
        
        raise OSError('JVM is already started')
        return x
    
    global _JVM_started
    if _JVM_started:
        x=-1
        
        raise OSError('JVM cannot be restarted')
        return x
    
@author: mczerniewski
"""

import sys
import paramiko
import getpass

import os
import jpype
from jpype import startJVM, shutdownJVM, java, addClassPath, JClass, JInt

import jpype.imports


class SshConnectorJpype:

    #def __init__(self):
    def __init__(self,main): 
        super().__init__()
        print("init SshConnection")
        self.main=main
       


        x=jpype.startJVM(jpype.getDefaultJVMPath(), "-ea",classpath=["C:/SshJavaJarPy7/"] )
     
        #classpath=["C:/SshJavaJarPy7/"]
        JClass=jpype.JClass("SshConnector")
     
        self.instance=JClass()  
        
        self.SshIp="172.20.5.223"
        self.SshPort="22"
        self.getParams()
        # self.ssh_connect(self.SshIp, self.user,self. key)
        # rv=self.instance.sendCommand('ls')
        # print('rv=',rv)
        
    def getParams(self):
        
 
        print("SSH IP=", self.SshIp)
        print("SSH port=",self.SshPort)

    #cslled by main.connectSsh()
    def ssh_connect(self, SshIp, user, key):
        
        print("connect to IP=",SshIp," user=",user," pswd=",key)
        
      
        try:
       
            #JClass=jpype.JClass("SshConnector_jnk")
            JClass=jpype.JClass("SshConnector")
            self.instance=JClass()
            
            # ip="172.20.4.182"
            port=22
            ip=SshIp
            login=user
            password=key
            timeout=10 
            
            ip=self.instance.setIP(ip)
            ip_received=self.instance.getIP()
            print('ip_received=',ip_received)
            user=self.instance.setUser(login)
            user_received=self.instance.getUser()
            print('user_received=',user_received)
            password=self.instance.setPassword(password)
            pswd_received=self.instance.getPassword()
            print('password_received=',pswd_received)
            
            # if connected=0 connection is ok when connected-1 no connection
            self.connected=self.instance.open()
            print("SshConnectorJp from Remote connected=",self.connected)

            print('1 end of connecting ssh')
            
                      
            
            return self.connected       
        
        except Exception as e:
            print('Connection Failed')
            print(e)
            
        else:
            
        
            print("closing SSH connection")            
            self.sshClose()
                    
    def sshClose(self):
        print("SshConnector sshClose()")
        self.instance.close()
        #jpype.shutdownJVM()
    
    def sendTestMessages(self):
        #just for test
        x=self.instance.test1(java.lang.Integer(66))
        print("x=",x)
        
        rv=self.instance.sendCommand('pwd')
        print('rv=',rv)
        
        #change dir
        #rv=instance.sendCommand('cd ..')
        #print('rv=',rv)
        
        #rv=instance.sendCommand('ls')
        #print('rv=',rv)
        
        #rv=instance.sendCommand('cd /bin')
        #print('rv=',rv)
        
        rv=self.instance.sendCommand('ls')
        print('rv=',rv)
        
        #switch thru some Tx freqa thru SSH-mewsh
        ctl=self.instance.sendMessage_SSH()
        print("ctl=",ctl)
        
        
        
        #set IQ200 frequency thru SSH-mewsh
        ctl=self.instance.setFrequency(java.lang.Integer(950))
        print("ctl=",ctl)
        
        #exit mewsh
        ctl=self.instance.sendCommand('exit\r\n')
        print("ctl=",ctl)
        
        rv=self.instance.sendCommand('ls')
        print('rv=',rv)
        
        
        #get current SshConnector.java
        rev=self.instance.getRev()
        print("rev=",rev)


        rv=self.instance.sendCommand('pwd')
        print('rv=',rv)
     
    # def sendSshMessage(self):
    
    #     msg= self.main.ui.tf_SSH_MessageToSend.text()
    #     msg=msg+'\r'
    #     print("SshConnector get ssh msg from TextWindow msg=",msg)
    #     rv=self.instance.sendCommand(msg)
    #     print("msg sent rv=",rv)
    
    # function used to send SPI data    
    def sendSshCommand(self,msg):
        
        print("SshConnector send SshCommand() ssh msg=",msg)  
        rv=self.instance.sendCommand(msg)
        print("msg sent rv=",rv)
      
    def sendSshCommand1(self,msg):
        msg=msg+"\r"
        print("SshConnector send SshCommand() ssh msg=",msg)         
        self.instance.sendCommand(msg)
              


#con=SshConnectorJpype()

# instance.close()
# jpype.shutdownJVM()

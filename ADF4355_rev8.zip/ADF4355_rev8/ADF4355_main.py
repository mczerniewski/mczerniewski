# -*- coding: utf-8 -*-
"""
Created on Sat Nov 27 21:27:15 2021

@author: house

0x1041C,
0x61300B,
0xC00FBA,
0xB0ABCC9,
0x102D0428,
0x120000E7,
0x3540C3F6,
0x800025,
0x32008994,
0x30000003,
0x74BFFFF2,
0x418931,
0x200A00
Pfd=25 MHz 1163.77 MHz
"""
import math
from PllSettings import PllSettings

class ADF4355_main:
    
    def __init__(self,Fout):
        
        self.Fout=float(Fout)
        self.Reg=[]
        self.Reg = [0 for i in range(13)] 
        self.Fpd=25
        
        self.Autocal=1
        self.Prescaler=0          # 0 for 4/5 and 1 for 8/9
        self.PowerdownSD=0        # 1 power down
        self.SDLoadReset=0
        self.PhaseResync=1
        self.PhaseAdjust=1
        self.PhaseValue=0
        self.Muxout=6
        self.RefDoubler=0
        self.RefD2=4
        self.RefD2=0
        self.Rcounter=10  #ref divider
        self.DoubleBuff=0
        self.ChargePumpCurrent=2
        self.REFinMode=1         #0 for single 1 for diff input
        self.MuxLevel=1
        self.PDPolarity=1
        self.Powerdown=0         # 0 for Pwr down disable 1 for enable 
        self.CP3State=0
        self.CounterReset=0
        self.DitherScale=1       # temp
        self.ADF5355U4Dither1=1
        self.PulsedBleed=1
        self.ADF5355U4Dither2=1
        self.ABP=1
        self.ChargeCancellation=1
        self.CLKDivMode=1
        self.ClockDividerValue=1
        self.VtuneCalSet=1
        self.VCOBandDiv=1
        self.Timeout=32
        self.ALCTimeout=30
        self.SynthLockTimeout=20
        self.R10DB3129=0
        self.VCOReadback=0
        self.ADCClock=math.ceil((self.Fpd*1000000/100000 -2)/4)
        print('adc clk=',self.ADCClock)
        self.ADCEnable=1
        self.VCOSelect=1
        self.VCOBiasCode=1
        self.VCOBandSelect=0
        self.PhaseResyncTimer=2
        #24v ng try:
        self.PhaseResyncTimer=1
        self.RFoutBEnable=0
        self.RFoutBPower=0
        self.RFoutAEnable=1
        self.RFoutAPower=3
        
        #reg7
        self.LESync=1
        self.ReadSel=0
        self.SDTestmodes=0
        self.PLLTestmodes=0
        self.LDCycles=0
        self.LOLMode=1
        self.MTLD=0 # don't mute when not locked for now for testing
        self.FracNLDPrecision=3
        self.LDMode=0
        
        #reg8
        self.ALC=0
        # self.INT=140
        # self.FRAC1=2322999
        # self.FRAC2=756
        # self.MOD1=16777216
        # self.MOD2=5461
        self.MOD2max = 16383
        # self.OutputDivider=4
        #bogus
        self.CSR=1
        self.GatedBleed=0
        self.NegativeBleedOnOff=1
        self.VCOLDOPowerdown=1
        self.ExtVCOSel=0
        self.FeedbackSelect=1
        self.BleedCurrent=1
        self.VCOPowerdown=0
        self.RFoutBSelect=0
        self.ADCConversion=1
        
        
        self.pllSettings=PllSettings(Fout)
        #get PLL settings
        p=self.pllSettings.getPllParams()
        
        self.MOD1=int(p[0])
        self.MOD2=int(p[1])
        self.FRAC1=int(p[2])
        self.FRAC2=int(p[3])
        self.OutputDivider=int(p[4])
        self.INT=int(p[5])
        print('MOD1=',self.MOD1)
        print('MOD2=',self.MOD2)
        print('FRAC1=',self.FRAC1)
        print('FRAC2=',self.FRAC2)        
        print('OutputDiv=',self.OutputDivider)
        print('INT=',self.INT)
        print('0 for 4/5 1 for 8/9 prescaler=',self.Prescaler)
        self.RegisterContent()

            
    def RegisterContent(self):
            
         
            
            self.Reg[0] = int(
                self.Autocal * math.pow(2, 21) +
                self.Prescaler * math.pow(2, 20) +
                ((self.INT & 0xFFFF))* math.pow(2, 4) + 0
                )
            print ('R0=',hex(self.Reg[0]))
            
            self.Reg[1]=5
            self.Reg[1] = int(
                self.PowerdownSD * math.pow(2, 28) +
                ((self.FRAC1 & 0xFFFFFF)) * math.pow(2, 4) + 1
                )
            print ('R1=',hex(self.Reg[1]))
    
            self.Reg[2] = int(
                ((self.FRAC2 & 0x3FFF))* math.pow(2, 18) +
                ((self.MOD2 & 0x3FFF)) * math.pow(2, 4) + 2
                )
            print ('R2=',hex(self.Reg[2]))
    
            self.Reg[3] = int(
                self.SDLoadReset * math.pow(2, 30) +
                self.PhaseResync * math.pow(2, 29) +
                self.PhaseAdjust * math.pow(2, 28) +
                float(self.PhaseValue) * math.pow(2, 4) + 3
                )
            print ('R3=',hex(self.Reg[3]))
    
            self.Reg[4] = int(
                #Dither2ndStage * math.pow(2, 30) +
                self.Muxout * math.pow(2, 27) +
                self.RefDoubler * math.pow(2, 26) +
                self.RefD2* math.pow(2, 25) +
                self.Rcounter* math.pow(2, 15) +
                self.DoubleBuff * math.pow(2, 14) +
                self.ChargePumpCurrent * math.pow(2, 10) +
                self.REFinMode * math.pow(2, 9) +
                self.MuxLevel * math.pow(2, 8) +
                self.PDPolarity * math.pow(2, 7) +
                self.Powerdown * math.pow(2, 6) +
                self.CP3State * math.pow(2, 5) +
                self.CounterReset * math.pow(2, 4) + 4
                )
            print ('R4=',hex(self.Reg[4]))  
            
            self.Reg[5] = int(
                self.DitherScale * math.pow(2, 29) +
                self.ADF5355U4Dither1 * math.pow(2, 28) +
                self.PulsedBleed * math.pow(2, 25) +
                #BandSelectClockMode * math.pow(2, 24) +
                self.ADF5355U4Dither2 * math.pow(2, 24) +
                self.ABP * math.pow(2, 23) +
                self.ChargeCancellation * math.pow(2, 22) +
                self.CSR * math.pow(2, 19) +
                self.CLKDivMode * math.pow(2, 16) +
                float(self.ClockDividerValue) * math.pow(2, 4) +  5
                )
            #fixed=self.Reg[5]
            self.Reg[5]=8388645            
            print ('R5=',hex(self.Reg[5]))    
                                      
            self.Reg[6] = int(    
                # ADF4355-2 - GOOD
                self.GatedBleed * math.pow(2, 30) +
                self.NegativeBleedOnOff * math.pow(2, 29) +
                self.VCOLDOPowerdown * math.pow(2, 28) +
                1 * math.pow(2, 26) +
                self.ExtVCOSel * math.pow(2, 25) +
                self.FeedbackSelect * math.pow(2, 24) +
                self.OutputDivider * math.pow(2, 21) +
                
                float(self.BleedCurrent* math.pow(2, 13)) +
                self.VCOPowerdown * math.pow(2, 12) +
                self.MTLD * math.pow(2, 11) +
                self.RFoutBSelect * math.pow(2, 10) +
                self.RFoutBEnable * math.pow(2, 9) +
                
                self.RFoutBPower * math.pow(2, 7) +
                self.RFoutAEnable * math.pow(2, 6) +
                self.RFoutAPower * math.pow(2, 4) +  6
                )
    
            print ('R6=',hex(self.Reg[6]))   
            
            self.Reg[7] = int(
                1*math.pow(2, 28) +
                1*self.LESync * math.pow(2, 25) +
                self.ReadSel * math.pow(2, 22) +
                self.SDTestmodes * math.pow(2, 16) +
                self.PLLTestmodes * math.pow(2, 12) +
                self.LDCycles * math.pow(2, 8) +
                self.LOLMode * math.pow(2, 7) +
                self.FracNLDPrecision * math.pow(2, 5) +
                self.LDMode * math.pow(2, 4) +  7
                )
    
            print ('R7=',hex(self.Reg[7]))   
 
            self.Reg[8] = int(
                0x102D04 * math.pow(2, 8) +
                self.VtuneCalSet * math.pow(2, 5) +
                self.ALC * math.pow(2, 4) + 8)
            print ('R8=',hex(self.Reg[8])) 
    
            self.VCOBandDiv=int(self.Fpd/(11*16))
            self.VCOBandDiv=3 #104kHz
            self.Timeout=9
            self.ALCTimeout=30
            self.SynthLockTimeout=12
            print(50*30/self.Fpd)
            print('self.SynthLockTimeout =',self.SynthLockTimeout )
            
            print(self.SynthLockTimeout * self.ALCTimeout/self.Fpd)
            
            self.Reg[9] = int(
                self.VCOBandDiv * math.pow(2, 24) +
                self.Timeout * math.pow(2, 14) +
                self.ALCTimeout * math.pow(2, 9) +
                self.SynthLockTimeout * math.pow(2, 4)
                +9
                )
            print ('R9=',hex(self.Reg[9])) 
    

            self.Reg[10] = int(
                self.R10DB3129 * math.pow(2, 29) +
                self.VCOReadback * math.pow(2, 26) +
                3 * math.pow(2, 22) +
                #float(Math.Round(self.ADCClock, 0, MidpointRounding.AwayFromZero)) * math.pow(2, 6) +
                float(round(self.ADCClock, 0)) * math.pow(2, 6) +
                self.ADCConversion * math.pow(2, 5) +
                self.ADCEnable * math.pow(2, 4) +                    
                0xA
                #0x0000001A
                )
            print ('R10=',hex(self.Reg[10]))
    
    
            #fixed 0x0061300B
            self.Reg[11] = int(
                0x6 * math.pow(2, 20) +
                self.VCOSelect * math.pow(2, 16) +
                3*self. VCOBiasCode * math.pow(2, 12) +
                float(self.VCOBandSelect * math.pow(2, 4)) + 0xB
                )
            #self.Reg[11]=6369291
            print ('R11=',hex(self.Reg[11]))  
    
            self.Reg[12] = int(
                float(self.PhaseResyncTimer * math.pow(2, 16)) +
                #1 * math.pow(2, 10) +
                #0x5F * math.pow(2, 4) +         # post Aug 2015 PCN - NOT HAPPENING
                0x41 * math.pow(2, 4) +          # pre Aug 2015 PCN - Permanent
                0xC
                )
           
            print ('R12=',hex(self.Reg[12]))           
        
        
    def getRegValues(self):
        
        return self.Reg[0]
        
        
        
#pll=ADF4355_main(121.325)
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 17 11:51:00 2021

@author: house
"""



import spidev
import time
#import sys

class SpiUtil:
    
    
    def __init__(self):
    
        print("init Raspi SpiConnection")
        self.SpiCe='9'
        self.mode='9'
        self.lsbfirst='9'
        self.loopback='9'
        self.cshigh='9'
  
        # self.bus=0 # Raspi 4 only 1 bus         
        # self.loopback=loopback
        # self.spi.max_speed_hz = speed   
        # self.lsbFirst=lsbFirst
    
    def getSpi(self):   
          
        self.spi = None  
        print('Raspi SPI CE=',self.SpiCe)
        print('Raspi SPI mode=',self.mode)
        print('Raspi CE active high=',self.cshigh)
        print('lsb first=',self.lsbfirst)
        print('loopback=',self.loopback)
        print('RASPI SPI speed=',self.max_speed_hz)        
        try: 
            
              
            self.spi = spidev.SpiDev()               
            self.spi.open(0, self.SpiCe)            
            self.spi.max_speed_hz = self.max_speed_hz           
            #self.spi.lsbfirst =self.lsbFirst
            self.spi.mode =self.mode 
            
            # if Mode==0:
            #     self.spi.mode = 0b00
            # if Mode==1:
            #     self.spi.mode = 0b01
            # if mode==2:
            #     self.spi.mode = 0b10
            # if mode==3:
            #     self.spi.mode = 0b11  
                
            # example:  self.spi.mode = 0b10    # CPOL=1 & CPHA=0 
            # mode - SPI mode as two bit pattern of clock polarity and phase [CPOL|CPHA],
            # min: 0b00 = 0, max: 0b11 = 3
            # Depending on CPOL parameter, SPI clock may be inverted or non-inverted
            # If CPHA=0 the data are sampled on the leading (first) clock edge. 
            # If CPHA=1 the data are sampled on the trailing (second) clock edge
            # regardless of whether that clock edge is rising or falling.
         
            # self.spi.cshigh = False
            # https://github.com/raspberrypi/linux/issues/3745
              
        except Exception as e:
            print('Can not open Raspi SPI port')
            
    
    # receives this info from SpiCOnnector via SSH
    def getData(self,ce,Mode,cepol,lsb,loopback):
        
        print("Raspi getData() got=",ce,Mode,cepol,lsb,loopback)
         
        # # SPI CE pin for SPI0/SPI1
        self.SpiCe=ce
            
        print("Raspi Mode=",Mode)
        if Mode==0:
            self.mode = 0b00
        if Mode==1:
            self.mode = 0b01
        if Mode==2:
            self.mode = 0b10
        if Mode==3:
            self.mode = 0b11 
               
        #CS could be high or low during data transfer   
     
            
        if cepol=='1':
                self.cshigh=True
                
        if cepol==0:
            self.cshigh=False
        if cepol==1:
            self.cshigh=True
        if lsb==1:
            self.lsbfirst=True
        else:
            self.lsbfirst=False 
    
        if loopback==1:
            self.loopback=True
        else:
            self.loopback=False
         
        #fixed
        self.max_speed_hz=7629
        print ('Raspi getData()')
        print('Raspi SPI CE=',self.SpiCe)
        print('Raspi SPI mode=',self.mode)
        print('Raspi SPI cshigh=',self.cshigh)
        #print('Raspi CS pol=',self.cepol)
        print('Raspi lsb first=',self.lsbfirst)
        print('Raspiloopback=',self.loopback)
        print('Raspi SPI speed=',self.max_speed_hz)
        
        #msg="SpiCe="+self.SpiCe+" m="+self.mode + " cshigh="+self.cshigh+" lsbFirst="+self.lsbfirst+" loopbac="+self.loopback
        msg="SpiUtil gotData for setting Raspi SPI"
        return msg
    def test(self):
        print("test from spi")
        spi = spidev.SpiDev()
        spi.open(0, 0)
        spi.max_speed_hz = 7629
        
    # Split an integer input into a two byte array to send via SPI
    # self.spi.cs = True
    # self.spi.transfer(data)
    # self.spi.cs = False
    def write1byteToSpi(self,b1):        
    
        self.spi.xfer([b1])        
    
    def write2bytesToSpi(self,b1,b2):
        
        self.spi.xfer([b1,b2])   
        
    def write3bytesToSpi(self,b1,b2,b3):
        
        self.spi.xfer([b1,b2,b3])
    
    def write4bytesToSpi(self,b1,b2,b3,b4):
        
        self.spi.xfer([b1,b2,b3,b4])
                      
    # write 2 bytes to SPI
    def writeWord(self,input):
        
        # spi = spidev.SpiDev()
        # spi.open(0, 0)
        # spi.max_speed_hz = 7629
        
    
        msb=input & 0xF0
        print('msb',msb)
        
        lsb=input&0x0F
        self.spi.xfer([msb, lsb])
        print('lsb',lsb)
        
        # # Repeatedly switch a MCP4151 digital pot off then on
        # while True:
        #     msb = input >> 8
        #     print('msb=',msb)
        #     lsb = input & 0xFF
        #     spi.xfer([msb, lsb])
        #     print('lsb=',lsb)

    def SpiClose(self):
        self.spi.close()      
        
su=SpiUtil()
su.test()


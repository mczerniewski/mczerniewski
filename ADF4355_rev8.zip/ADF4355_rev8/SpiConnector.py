# -*- coding: utf-8 -*-
"""
Created on Thu Nov 18 11:59:38 2021

@author: house
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Oct  4 16:49:36 2021

@author: mczerniewski
"""
import sys
import time

import sys
from threading import Thread
import getpass
import os


import struct

class SpiConnector:
    
    def __init__(self,main):
      
        super().__init__()
        print("init SpiConnection")
        self.main=main
        self.SpiClock='8'
        self.SpiMode ='0'      
        self.SpiLsbFirst='1'
        self.CEpol='0'
        self.Spi0Bus='0'
        self.Spi1Bus='1'
        self.SpiLoopback='0'
        self.bits_per_word = 32        
        self.spiConnected=False
        self.getParams()
      
    
    def getParams(self):
        
        # for raspberry Pi 4
    
        #not used on this raspi - bus ng
        self.Spi0Bus='0'        
        
        self.Spi1Bus='1'
        #self.Spi1Bus='0'  
        
        self.CEpol='0'
        #self.CEpol='1'
        
        self.SpiLsbFirst='1'
        self.SpiLsbFirst='0'
 
        #self.SpiLoopback='1'
        self.SpiLoopback='0'        
        
        #mode0
        # self.mode = '0b00'
        # # self.SpiMode='1':
        # self.mode = '0b01'
        # #self.SpiMode='2':
        # self.mode = '0b10'
        # #self.SpiMode=='3':
        # self.mode = '0b11'  
        
        self.SpiMode="0"
                
        print("self.SpiClock=", self.SpiClock)
        print("self.SpiMode=",self.SpiMode) 
        print("self.SpiMsbFirst=",self.SpiLsbFirst)
        print("self.Spi0Bus=",self.Spi0Bus)
        print("self.Spi1Bus=",self.Spi1Bus)  
        print("self.SpiLoopback=",self.SpiLoopback)
        
        
    def spiConnect(self):
        
        print("connect to SPI bus")        
      
            #try:
         
        msg="pwd"  
        self.main.sshConnector.sendSshCommand(msg)
        msg='cd pyApps'
        self.main.sshConnector.sendSshCommand(msg)
        time.sleep(1)
        msg='ls -ltr'
        self.main.sshConnector.sendSshCommand(msg)
        msg='python' 
        self.main.sshConnector.sendSshCommand(msg)                     
        msg="exec(open('SpiUtil.py').read())"
        self.main.sshConnector.sendSshCommand(msg)
        
        #set Raspi SPI
        x1=self.Spi1Bus     #use Spi1Bus       
        x2=self.SpiMode
        x3=self.CEpol
        x4=self.SpiLsbFirst
        x5=self.SpiLoopback
        msg="su.getData("+x1+','+x2+','+x3+','+x4+','+x5+")"
        self.main.sshConnector.sendSshCommand(msg)   
        msg="su.getSpi()"                
        self.main.sshConnector.sendSshCommand(msg)

        self.spiConnected=True
        
    # except Exception as e:
    #     print('SpiConnector.py Connection Failed')
    #     print(e)

                
                 
    def closeSpi(self):
        
        print("closing SPI connection")                    
      
        msg="su.SpiClose()"
        self.main.sshConnector.sendSshCommand(msg) 
        msg="exit()"
        self.main.sshConnector.sendSshCommand(msg) 
        self.spiConnected=False
        
    def sendSpiMessage(self):
    
          self.sendByteArrayToSPI()
         

    # send data to SPI port
    def sendByteArrayToSPI(self,valuesList):

        print("sendByteArrayToSPI()")    
        print('text=',valuesList)
        hexWords=[]
        for word in valuesList.split(','):
                print('word=',word)
                # numOfChars=len(word.encode("utf8"))-2
                # print('num of chars=',numOfChars)
                # numOfBytes=round((numOfChars)/2+.6)
                # if numOfBytes>4:
                #     numOfBytes=4
                # #numOfBytes=round((numOfChars)/2)
                # print('numOfBytes=',numOfBytes)
                hexWords.append(word)
        L=len(hexWords)
       
        
        #packing" with format '>I' makes x into a 4-byte string in big-endian order,
        #which can then "unpacked" into four unsigned byte-size values with format '4B'.
        numOfBytes=4
        print('num of bytes to send L=',L)
        for i in range(0,L):
        
            temp=hexWords[i]
            # if temp==0xc00fba:
            #    temp=0xC0033A
            #print(i,"\t",temp)
            num=int(temp,16)
            p=struct.unpack('4B', struct.pack('>I', num))  
            # print('p=',p)
            # print(i,"\t",temp,"\t",p[0],p[1],p[2],p[3])
            print('i=',i,"\t",temp,"\t",hex(p[0]),hex(p[1]),hex(p[2]),hex(p[3]))
                
            x1=p[0]
            x2=p[1]
            x3=p[2]
            x4=p[3]
                
            x1=str(hex(p[0]))
            x2=str(hex(p[1]))
            x3=str(hex(p[2]))
            x4=str(hex(p[3]))
                
            msg="su.write4bytesToSpi("+x1+','+x2+','+x3+','+x4+")"            
                                                                      
            self.main.sshConnector.sendSshCommand(msg)           
                                                                      
            
    def resetSpiConfig(self):
          print("reset Spi Config")
          self.closeSpi()
          self.getParams()
          self.spiConnect()
          
            
            
